import React from 'react'

function NoMatch() {
  return (
    <div>
      <h1>THIS IS NO MATCH PAGE</h1>
      <h2> NO MATCH PAGE INFORMATION</h2>
    </div>
  )
}

export default NoMatch
